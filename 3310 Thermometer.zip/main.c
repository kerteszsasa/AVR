//********************************************************
//***** PROGRAM FOR Interfacing NOKIA 3310 Display ******
//********************************************************
//Controller:	ATmega8 (Clock: 1 Mhz-internal)
//Compiler:		ImageCraft ICCAVR
//Author:		CC Dharmani, Chennai (India)
//			www.dharmanitech.com
//Date:			Sep 2008
//********************************************************

#include <iom8v.h>
#include <macros.h>
#include "3310_routines.h"
#include "ds1621.h"

void port_init(void)
{
 PORTB = 0xFF;
 DDRB  = 0xFF;
 PORTC = 0x00; //m103 output only
 DDRC  = 0x00;
 PORTD = 0x00;
 DDRD  = 0xFF;
}

//SPI initialize
//clock rate: 250000hz
void spi_init(void)
{
 SPCR = 0x58; //setup SPI
}

//TWI initialize
// bit rate:2 (freq: 50Khz)
void twi_init(void)
{
 TWCR= 0X00; //disable twi
 TWBR= 0x02; //set bit rate
 TWSR= 0x00; //set prescale
 TWAR= 0x00; //set slave address
 TWCR= 0x44; //enable twi
}

//call this routine to initialize all peripherals
void init_devices(void)
{
 //stop errant interrupts until set up
 CLI(); //disable all interrupts
 port_init();
 spi_init();
 twi_init();
 
 MCUCR = 0x00;
 GICR  = 0x00;
 TIMSK = 0x00; //timer interrupt sources
 //SEI(); //re-enable interrupts
 //all peripherals are now initialized
}

//
void main(void)
{
 unsigned char i, j, k, LED=0;
 unsigned char* tempDisplay;
 
 init_devices();
 
 LCD_init();
 ds1621_init(); //disable this line if you don't have this chip connected
		//otherwise display may remain blank
 
 delay_ms(100);	   //delay for ds1621 write complete
 
 LCD_drawBorder();
 
 LCD_gotoXY (4,1);
 LCD_writeString_F("Thermometer");
 
 LCD_gotoXY (4,5);
 LCD_writeString_F("by DHARMANI");
 
 i=0;

 while(1)
 {
   if(LED == 0) 
   {
     PORTD |= 0x01;
	 LED = 1;
   }
   else
   {
     PORTD &= ~0x01;
	 LED = 0;
   } 
   
   tempDisplay = getTemperature();
   LCD_gotoXY (4,1);
   LCD_writeString_megaFont ( tempDisplay );
   
 }  
   
}